//
//  KeepRoute.swift
//  com.egco428.qz3088
//
//  Created by 6272 on 12/7/2560 BE.
//  Copyright © 2560 6272. All rights reserved.
//

import UIKit

class KeepRoute: UIViewController {

    
    @IBOutlet weak var startBtn: UIButton!
    @IBOutlet weak var textField: UITextField!
    var routeName:String!
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let detailViewController = segue.destination as! RouteMap
        let nameRoute = textField.text
        detailViewController.nameRoute = nameRoute
    }
    
}
