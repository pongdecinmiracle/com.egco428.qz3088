//
//  KeepDrivingViewController.swift
//  com.egco428.qz3088
//
//  Created by 6272 on 12/7/2560 BE.
//  Copyright © 2560 6272. All rights reserved.
//

import UIKit
import Firebase

class KeepDrivingViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var ref: DatabaseReference!
    @IBOutlet weak var tableView: UITableView!
    var locationName:Array<String> = []
    var latitude:Array<String> = []
    var longtitude:Array<String> = []
    var tempTime:String!
    var i:Int = 0
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locationName.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = locationName[indexPath.row]
//        cell.backgroundColor = #colorLiteral(red: 1, green: 0.8323456645, blue: 0.4732058644, alpha: 1)
        return cell    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        receiveData()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func  prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let indexPath = self.tableView.indexPathForSelectedRow{
            let locationNames = self.locationName[indexPath.row]
            (segue.destination as! RouteView).locationName = locationNames
      
            
        }
    }
    
    @IBAction func addRoute(_ sender: Any) {
        performSegue(withIdentifier:"toKeepRoute" , sender: self)
    }
    
    func receiveData(){
        ref = Database.database().reference()
        ref.child("users").observe(DataEventType.value, with: {(snapshot) in
            if snapshot.exists() {
                let valueFir = snapshot.value as! NSDictionary
                let keyList = valueFir.allKeys as! [String]
                for i in keyList{
                    let user = valueFir.value(forKey: i) as! NSDictionary
                    let thisUsername = user.value(forKey: "username") as! String
                    let lat = user.value(forKey: "latitude") as! String
                    let long = user.value(forKey: "longtitude") as! String
                    self.locationName.append(thisUsername)
                    self.latitude.append(lat)
                    self.longtitude.append(long)
                    print(self.locationName)
                    self.i = self.i+1

                }
                
            }else{
                print("err")
//                self.tempTime = "No Schedule in this Route"
//                self.listTime.append(self.tempTime)
            }
            self.tableView.reloadData()
            
        })
        //        return self.listTime
    }

}
