//
//  RouteMap.swift
//  com.egco428.qz3088
//
//  Created by 6272 on 12/7/2560 BE.
//  Copyright © 2560 6272. All rights reserved.
//

import UIKit
import MapKit
import Firebase

class RouteMap: UIViewController,MKMapViewDelegate  {

    var ref: DatabaseReference!
    
    @IBOutlet weak var textField1: UITextField!
    @IBOutlet weak var textField2: UITextField!
    @IBOutlet weak var mapView: MKMapView!
    var nameRoute:String! = ""
    var latitude:Array<Double> = [13.7942321]
    var longitude:Array<Double> = [100.3264753]
    var i:Int = 0
    
    var randNumber:Double! =  Double((Double(arc4random_uniform(100000))/100000000)-0.0090000)

    
    override func viewDidLoad() {
        super.viewDidLoad()
        ref = Database.database().reference()
        print("nameRoute is")
        print(nameRoute)
        setCenterOfMap()
        

        // Do any additional setup after loading the view.
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?) {
        let lat:Double = 13.7942321+self.randNumber
        let long:Double = 100.3264753+self.randNumber
        textField1.text = "\(lat)"
        textField2.text = "\(long)"
        latitude.append(lat)
        longitude.append(long)
        
        print("XXXXX")
        print(latitude)
        print(longitude)
        let j = (latitude.count)
        
        for _ in latitude{
            let Location = CLLocationCoordinate2DMake(latitude[self.i],longitude[self.i] )
            let annotation = MapMaker(coordinate: Location, title: "\(textField1)", subtitle: "\(textField2)")
            mapView.addAnnotation(annotation)
            
            //        setCenterOfMapToLocation(location: centerLocation)
            self.i = self.i+1
            if self.i == latitude.count{
                break
            }
        }
//        let Location = CLLocationCoordinate2DMake(lat ,long )
//        let annotation = MapMaker(coordinate: Location, title: "ตึกอธิการ", subtitle: "OP Building")
//        mapView.addAnnotation(annotation)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func saveBtn(_ sender: Any) {
        let isFieldEmpty = (textField1.text?.isEmpty)! || (textField2.text?.isEmpty)!
        if !isFieldEmpty {
            let isAvaliable = true
                if isAvaliable {
                    let key = self.ref.child("users").childByAutoId().key
                    let post = ["username": self.nameRoute,
                        "latitude": Double(self.textField1.text!)!,
                        "longtitude": Double(self.textField2.text!)!] as [String : Any]
                    let childUpdate = ["/users/\(key)": post]
                    self.ref.updateChildValues(childUpdate)
                    print("Save data successfully")
                    self.navigationController?.popViewController(animated: true)
                    self.dismiss(animated: true, completion: nil)
                }
        
        }else {
            print("Some field is empty!")
        }
    }
    
    func setCenterOfMap(){
        let location = CLLocationCoordinate2D(latitude: 13.7934, longitude: 100.3225)
        
        let region = MKCoordinateRegionMakeWithDistance(location, 500.0, 1500.0)
        mapView.setRegion(region, animated: true)
    }
}

